//Azucena Marroquin
//atrevizo4@cnm.edu
//12Jan2022-Program 0


#include <iostream>

using namespace std;


	int main() {
		//Header
		cout << "Azucena Marroquin" << endl;

		cout << "Program- Hello World" << endl;

		cout << "Objective- creation of Hello World program with output to the console" << endl;

		//Objective output
		cout << "Hello World!" << endl;

		return 0;
	}
